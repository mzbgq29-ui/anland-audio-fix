#!/usr/bin/env python3
"""Verify PulseAudio-compatible application playback reaches Anland."""
import json
from pathlib import Path
import subprocess
import time

work = Path(__file__).resolve().parent
name = 'anland-pulse-routing-regression'
player = subprocess.Popen(['paplay', '--client-name=' + name,
    '--stream-name=' + name, str(work / 'anland-routing-silence.wav')],
    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
try:
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        objects = json.loads(subprocess.check_output(['pw-dump'], text=True, timeout=5))
        nodes = [o for o in objects if o['type'] == 'PipeWire:Interface:Node']
        sink = next((o for o in nodes if o['info']['props'].get('node.name') == 'anland-speaker'), None)
        stream = next((o for o in nodes if o['info']['props'].get('media.name') == name), None)
        if sink and stream:
            links = [o for o in objects if o['type'] == 'PipeWire:Interface:Link'
                and o['info']['props'].get('link.output.node') == stream['id']
                and o['info']['props'].get('link.input.node') == sink['id']]
            if len(links) >= 2 and all(o['info']['state'] == 'active' for o in links):
                result = {'api': 'PulseAudio compatibility', 'default_routing': True,
                    'sink_name': 'anland-speaker', 'active_stereo_links': len(links)}
                break
        time.sleep(0.1)
    else:
        raise AssertionError('PulseAudio stream did not automatically route to Anland')
    _, stderr = player.communicate(timeout=6)
    assert player.returncode == 0, stderr.decode()
    (work / 'pulse-route-validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
finally:
    if player.poll() is None:
        player.terminate()
        player.communicate(timeout=5)
