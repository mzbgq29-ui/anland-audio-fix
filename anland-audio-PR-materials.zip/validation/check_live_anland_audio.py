import json
from pathlib import Path
import subprocess
import time
import wave

ROOT = Path(__file__).parent
wav = ROOT / 'anland-routing-silence.wav'
with wave.open(str(wav), 'wb') as f:
    f.setnchannels(2)
    f.setsampwidth(2)
    f.setframerate(48000)
    f.writeframes(bytes(48000 * 4 * 4))

checks = []
for attempt in range(3):
    subprocess.run(['systemctl', '--user', 'restart', 'wireplumber.service'], check=True)
    name = f'anland-audio-routing-regression-{attempt}'
    player = subprocess.Popen(['pw-cat', '--playback', '--properties',
        f'{{ node.name = {name} }}', str(wav)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            objects = json.loads(subprocess.check_output(['pw-dump'], text=True, timeout=5))
            nodes = {o['id']: o for o in objects if o['type'] == 'PipeWire:Interface:Node'}
            by_name = {o['info']['props'].get('node.name'): o for o in nodes.values()}
            sink = by_name.get('anland-speaker')
            stream = by_name.get(name)
            if sink and stream:
                links = [o for o in objects if o['type'] == 'PipeWire:Interface:Link'
                    and o['info']['props'].get('link.output.node') == stream['id']
                    and o['info']['props'].get('link.input.node') == sink['id']]
                if len(links) >= 2 and all(o['info']['state'] == 'active' for o in links):
                    cameras = sorted(n for n in by_name if n and n.startswith('anland-camera-'))
                    assert 'anland-mic' in by_name and len(cameras) >= 2
                    check = {'restart': attempt + 1, 'sink': sink['id'],
                        'default_application_routing': True, 'active_audio_links': len(links),
                        'microphone_present': True, 'virtual_cameras': cameras}
                    checks.append(check)
                    print(json.dumps(check), flush=True)
                    break
            time.sleep(0.1)
        else:
            raise AssertionError('Application audio did not automatically link to Anland speaker')
        stdout, stderr = player.communicate(timeout=6)
        assert player.returncode == 0, stderr.decode()
    finally:
        if player.poll() is None:
            player.terminate()
            player.communicate(timeout=5)

(ROOT / 'live-anland-audio-validation.json').write_text(json.dumps(checks, indent=2) + '\n')
print('PASS: default stereo routing survives three WirePlumber restarts')
