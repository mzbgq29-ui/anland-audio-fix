#!/usr/bin/env python3
"""Exercise the repaired session with and without the Android device filter."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
config = Path('/etc/wireplumber/wireplumber.conf.d/50-anland-audio.conf')
disabled = work / 'backups/50-anland-audio.conf.disabled-for-rootfix-test'
assert config.is_file() and not disabled.exists()
original_hash = hashlib.sha256(config.read_bytes()).hexdigest()
started = datetime.now(timezone.utc).isoformat()
report = {'started_utc': started, 'phases': {}}

def route_check(phase):
    subprocess.run([sys.executable, str(work / 'check_live_anland_audio.py')], check=True)
    result = (work / 'live-anland-audio-validation.json').read_text()
    (work / f'live-anland-audio-{phase}.json').write_text(result)
    report['phases'][phase] = json.loads(result)

try:
    subprocess.run(['sudo', '-n', 'mv', str(config), str(disabled)], check=True)
    route_check('without-filter')
finally:
    if disabled.exists():
        subprocess.run(['sudo', '-n', 'mv', str(disabled), str(config)], check=True)
    subprocess.run(['systemctl', '--user', 'reset-failed', 'wireplumber.service'], check=True)
    subprocess.run(['systemctl', '--user', 'restart', 'wireplumber.service'], check=True)
    assert hashlib.sha256(config.read_bytes()).hexdigest() == original_hash

route_check('with-filter')
report['restored_filter_sha256'] = original_hash
report['packages'] = subprocess.check_output(
    ['pacman', '-Q', 'libpipewire', 'libwireplumber'], text=True).strip().splitlines()
report['services'] = subprocess.check_output(
    ['systemctl', '--user', 'is-active', 'pipewire', 'wireplumber'], text=True).strip().splitlines()
logs = subprocess.check_output(['sudo', '-n', 'journalctl',
    '_SYSTEMD_USER_UNIT=wireplumber.service', '_UID=1000',
    '--since', started, '--no-pager', '-o', 'short-iso'], text=True)
(work / 'installed-rootfix-wireplumber.log').write_text(logs)
(work / 'installed-rootfix-validation.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: installed root fixes route audio with and without the filter; configuration restored')
