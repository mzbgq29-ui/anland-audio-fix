# Anland 音频修复与 PR 材料

本机这次无声故障已修复，修复后的库已通过 pacman 安装，当前 PipeWire、PipeWire Pulse、WirePlumber 均在运行。

## 提交 Anland PR

- 目标仓库：[SuperTurtleDev/anland](https://github.com/SuperTurtleDev/anland)。
- **目标分支：`legacy`**。当前桌面使用的是 legacy 音频链路。
- 补丁：`anland-audio-fix.patch`，包含 19 个文件的完整修改及新增配置、构建 helper、回归测试。
- 基线：`a271f010b0f2ed413e193e779e38daa77070c974`。
- 英文标题和正文：`PR_BODY.md`。
- 工作树：`/home/mzbgq/Documents/Codex/2026-10-12/root/work/anland-legacy`，分支 `fix/android-camera-audio-routing`。改动保留在工作树，尚未提交或推送。

补丁已在独立 Git index 中验证能应用到干净基线，没有修改工作树的暂存状态。若在自己的 fork 中使用，切到基于上述 legacy 基线的分支后运行：

```sh
git apply --check /path/to/anland-audio-fix.patch
git apply /path/to/anland-audio-fix.patch
python3 -m unittest discover -s libdisplay_producer/wireplumber/tests -v
```

测试需要 Python 3、PipeWire 的 `spa-json-dump`、Bash，以及 `dpkg` 或 `vercmp`。如果上游 legacy 后续发生变化，请先检查补丁上下文。

## 修复内容

Anland 增加按 sysfs 身份匹配的高通控制／编解码设备过滤规则，并让 KDE、GNOME、Niri、Gamescope producer 包安装规则。没有按 `/dev/videoN` 编号过滤，也没有关闭整个视频捕获功能。软件包版本约束排除了带有额外异步 hook 回归的 WirePlumber 0.5.16／0.5.17。

通用错误处理也准备了两份配套补丁，位于 `upstream-root-fixes/`：PipeWire 在 listener 初始化失败时销毁 proxy 并返回错误；WirePlumber 在 export 失败时结束 activation，使后续事件继续处理。这两份属于 PipeWire、WirePlumber 上游，详见该目录的 README。

## 本机验证

- 临时撤掉设备过滤规则，连续重启 WirePlumber 三次。真实 `/dev/video0`、`/dev/video1` 仍返回 EALREADY，但设备激活立即结束，应用每次均自动连到 `anland-speaker`。
- 恢复规则后再连续重启三次，立体声两条连线均 active。
- PulseAudio 兼容应用也自动连接到 `anland-speaker`。
- 麦克风及两个 Anland 虚拟摄像头节点仍存在。
- Anland 11 项回归、9 项安装／打包集成检查通过；两个已安装的根修库再次通过独立故障注入测试。

详细证据见 `VALIDATION_zh.md` 和 `validation/`。尚未测试整机重启、实际 USB／远程摄像头视频捕获；本轮自动播放使用静音样本检查路由，没有重新请求听感确认。修复针对已经复现的故障原因，不承诺消除音量、Android 输出选择等其他无声原因。

## 当前系统与回退

本机安装的版本为 `libpipewire 1:1.6.9-1.1` 和 `libwireplumber 0.5.18-1.1`；活动过滤配置位于 `/etc/wireplumber/wireplumber.conf.d/50-anland-audio.conf`。旧的全面禁用视频配置备份在工作目录的 `work/backups/`。

`local-arch-aarch64-packages/` 保存修补包、已验证官方签名的原版回退包，以及包内容检查结果。它们仅适用于本机对应的 Arch Linux ARM aarch64 基线，不属于 Anland 源码 PR。安装时使用了一份仅在该次命令中生效的本地包配置，全局 pacman 配置和签名设置没有修改。临时 WirePlumber 模块路径环境变量已移除。

以后发行版升级可能替换这些本地库；`/etc` 的过滤规则会保留，仍防止这组已知设备触发故障。底层补丁合入并随发行版发布后，可恢复使用发行版库。
