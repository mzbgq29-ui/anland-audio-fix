# WirePlumber device export error fix validation

Validated against WirePlumber 0.5.18 and PipeWire 1.6.9 on aarch64. The patched WirePlumber library was built from upstream source in this workspace. No installed library or running user service was changed.

## Missing V4L2 device regression

The test creates its own PipeWire server with a unique socket under `work/wp-rt`, loads no WirePlumber hardware monitors, and passes the deliberately nonexistent `work/absent` path to `api.v4l2.device`. It never opens an existing camera device. It tests both the main-context fallback and the threaded client context used by the default modern daemon, requests all WpSpaDevice features, and requires an activation callback within two seconds. After that error callback it performs an unrelated core synchronization.

| PipeWire module | WirePlumber library | Result |
| --- | --- | --- |
| Original 1.6.9 | Original 0.5.18 | No activation callback; eight second watchdog fired. |
| Original 1.6.9 | Patched 0.5.18 | No activation callback; eight second watchdog fired. |
| Patched 1.6.9 | Original 0.5.18 | NULL proxy assertion; the GLib test framework treats the critical as fatal. |
| Patched 1.6.9 | Patched 0.5.18 | PASS: failed-export callbacks in 0.470 ms (main context) and 0.299 ms (threaded client context); expected operation error; no proxy; no active features; subsequent core synchronization completed. |

Both fixes are necessary. PipeWire must propagate the listener error instead of returning an unbound proxy, and WirePlumber must terminate activation when the export returns NULL.

Logs:

- `wp-export-original-pair.log`
- `wp-export-old-pipewire.log`
- `wp-export-old-wp-patched-pw.log`
- `wp-export-patched-pair.log`

The old-pipewire log uses a longer intentionally nonexistent path; the V4L2 plugin truncated its internal path buffer. The final pair comparisons use the shorter `work/absent` path and preserve the full path.

## Existing upstream checks

Compiled the library and available C tests with GLib/GIO 2.90.1 and system PipeWire 1.6.9 headers. `test-core`, `test-events`, `test-object-manager`, `test-proxy`, and `test-transition` all passed (five suites, zero failures). The separate `test-client-context` suite then also passed. Its upstream test log: `wireplumber-0.5.18/build-rootfix/meson-logs/testlog.txt`.

## Artifacts

- Candidate patch: `wireplumber-device-export-error.patch`
- Compiled library: `wireplumber-0.5.18/build-rootfix/lib/wp/libwireplumber-0.5.so.0.518.0`
- Regression source: `wp-spa-device-export-error.c`
- Regression binary: `wp-spa-device-export-error`
- Isolated runner: `wp-run-export-regression.py`

Reproduce the passing case from the chat workspace:

```sh
python work/wp-run-export-regression.py \
  --module-dir /home/mzbgq/Documents/Codex/2026-10-12/root/work/pipewire-1.6.9/build-audio-fix/src/modules:/usr/lib/pipewire-0.3 \
  --log /home/mzbgq/Documents/Codex/2026-10-12/root/work/wp-export-patched-pair.log
```

The runner sets library/module directories only for its subprocess. The runtime directory, configuration paths, log files, and binaries remain inside `work/`.
