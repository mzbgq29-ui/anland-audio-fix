/* SPDX-License-Identifier: MIT
 * Regression test for a failed client-device export. Uses WirePlumber's
 * isolated test server and a deliberately nonexistent path; no real V4L2
 * device is enumerated or opened.
 */
#include "common/base-test-fixture.h"
#include <spa/utils/keys.h>

typedef struct {
  WpBaseTestFixture base;
  gboolean callback_called;
  gint64 started_at;
} ExportErrorFixture;

static void
client_context_loaded (WpCore *core, GAsyncResult *res, ExportErrorFixture *f)
{
  g_autoptr (GError) error = NULL;
  g_assert_true (wp_core_load_component_finish (core, res, &error));
  g_assert_no_error (error);
  g_main_loop_quit (f->base.loop);
}

static void
setup (ExportErrorFixture *f, gconstpointer threaded)
{
  wp_base_test_fixture_setup (&f->base, 0);
  if (threaded) {
    g_autoptr (WpSpaJson) args = wp_spa_json_new_from_string (
        "{ context.spa-libs = { "
        "api.v4l2.* = v4l2/libspa-v4l2 "
        "support.* = support/libspa-support "
        "audio.convert.* = audioconvert/libspa-audioconvert } }");
    wp_core_load_component (f->base.core, "client-context", "built-in", args,
        NULL, NULL, (GAsyncReadyCallback) client_context_loaded, f);
    g_main_loop_run (f->base.loop);
  }
}

static void
teardown (ExportErrorFixture *f, gconstpointer unused)
{
  wp_base_test_fixture_teardown (&f->base);
}

static void
activation_done (WpObject *object, GAsyncResult *res, ExportErrorFixture *f)
{
  g_autoptr (GError) error = NULL;
  gboolean success = wp_object_activate_finish (object, res, &error);
  gint64 elapsed = g_get_monotonic_time () - f->started_at;

  f->callback_called = TRUE;
  g_assert_false (success);
  g_assert_error (error, WP_DOMAIN_LIBRARY, WP_LIBRARY_ERROR_OPERATION_FAILED);
  g_assert_nonnull (strstr (error->message, "failed to export device"));
  g_assert_cmpint (elapsed, <, 2 * G_TIME_SPAN_SECOND);
  g_assert_null (wp_proxy_get_pw_proxy (WP_PROXY (object)));
  g_assert_cmphex (wp_object_get_active_features (object), ==, 0);
  g_test_message ("failed export callback in %.3f ms: %s",
      (double)elapsed / 1000, error->message);
  g_main_loop_quit (f->base.loop);
}

static void
missing_v4l2_device (ExportErrorFixture *f, gconstpointer unused)
{
  g_autoptr (WpSpaDevice) device = NULL;
  g_autoptr (WpProperties) props = NULL;
  const gchar *missing_path = g_getenv ("ANLAND_TEST_MISSING_V4L2_PATH");
  struct pw_context *ctx = wp_core_get_pw_context (f->base.core);

  g_assert_nonnull (missing_path);
  g_assert_false (g_file_test (missing_path, G_FILE_TEST_EXISTS));
  g_assert_cmpint (pw_context_add_spa_lib (ctx, "api.v4l2.*",
      "v4l2/libspa-v4l2"), ==, 0);
  /* The standard PipeWire client configuration loads client-device. */

  props = wp_properties_new (SPA_KEY_API_V4L2_PATH, missing_path, NULL);
  device = wp_spa_device_new_from_spa_factory (f->base.core,
      "api.v4l2.device", g_steal_pointer (&props));
  g_assert_nonnull (device);

  f->started_at = g_get_monotonic_time ();
  wp_object_activate (WP_OBJECT (device), WP_OBJECT_FEATURES_ALL, NULL,
      (GAsyncReadyCallback) activation_done, f);
  if (!f->callback_called)
    g_main_loop_run (f->base.loop);
  g_assert_true (f->callback_called);

  /* An unrelated core round trip still completes after the error. */
  wp_core_sync (f->base.core, NULL,
      (GAsyncReadyCallback) test_core_done_cb, &f->base);
  g_main_loop_run (f->base.loop);
}

int
main (int argc, char **argv)
{
  g_test_init (&argc, &argv, NULL);
  wp_init (WP_INIT_ALL);
  g_test_add ("/wp/spa-device/failed-export-completes", ExportErrorFixture,
      NULL, setup, missing_v4l2_device, teardown);
  g_test_add ("/wp/spa-device/failed-export-client-context", ExportErrorFixture,
      GINT_TO_POINTER (1), setup, missing_v4l2_device, teardown);
  return g_test_run ();
}
