/* SPDX-License-Identifier: MIT
 * Standalone regression code: synthetic SPA devices only; no hardware.
 */
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <spa/monitor/device.h>
#include <pipewire/pipewire.h>

struct fake_device {
  struct spa_device device;
  struct spa_hook_list hooks;
  int error;
  bool partial_listener;
  bool bound;
};

static int add_listener(void *object, struct spa_hook *hook,
    const struct spa_device_events *events, void *data)
{
  struct fake_device *d = object;
  if (d->partial_listener || !d->error)
    spa_hook_list_append(&d->hooks, hook, events, data);
  if (d->error)
    return -d->error;
  const struct spa_dict_item items[] = {
    SPA_DICT_ITEM_INIT("device.name", "anland-export-regression-device"),
  };
  const struct spa_dict props = SPA_DICT_INIT_ARRAY(items);
  const struct spa_device_info info = {
    .version = SPA_VERSION_DEVICE_INFO,
    .change_mask = SPA_DEVICE_CHANGE_MASK_FLAGS | SPA_DEVICE_CHANGE_MASK_PROPS,
    .props = &props,
  };
  if (events->info)
    events->info(data, &info);
  return 0;
}

static const struct spa_device_methods methods = {
  .version = SPA_VERSION_DEVICE_METHODS,
  .add_listener = add_listener,
};

static void bound(void *data, uint32_t global_id)
{
  struct fake_device *d = data;
  (void)global_id;
  d->bound = true;
}

static const struct pw_proxy_events proxy_events = {
  .version = PW_VERSION_PROXY_EVENTS,
  .bound = bound,
};

static double now(void)
{
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return t.tv_sec + t.tv_nsec / 1e9;
}

int main(int argc, char **argv)
{
  bool fixed = argc > 1 && strcmp(argv[1], "fixed") == 0;
  pw_init(&argc, &argv);
  struct pw_main_loop *loop = pw_main_loop_new(NULL);
  struct pw_context *context = pw_context_new(pw_main_loop_get_loop(loop), NULL, 0);
  struct pw_core *core = pw_context_connect(context, NULL, 0);
  if (!core) {
    perror("isolated core connection");
    return 2;
  }
  const int errors[] = { EALREADY, EIO, ENOMEM };
  for (unsigned i = 0; i < sizeof(errors) / sizeof(errors[0]); ++i) {
    for (int partial = 0; partial < 2; ++partial) {
      struct fake_device d = { .error = errors[i], .partial_listener = partial };
      spa_hook_list_init(&d.hooks);
      d.device.iface = SPA_INTERFACE_INIT(SPA_TYPE_INTERFACE_Device,
          SPA_VERSION_DEVICE, &methods, &d);
      errno = 0;
      struct pw_proxy *p = pw_core_export(core, SPA_TYPE_INTERFACE_Device,
          NULL, &d.device, 0);
      int saved_errno = errno;
      if (fixed && (p || saved_errno != errors[i])) {
        fprintf(stderr, "failed export returned proxy=%p errno=%d (expected %d)\n",
            (void *)p, saved_errno, errors[i]);
        return 1;
      }
      if (!fixed && !p) {
        fprintf(stderr, "baseline unexpectedly rejected the failing listener\n");
        return 1;
      }
      if (p)
        pw_proxy_destroy(p);
      if (!spa_list_is_empty(&d.hooks.list)) {
        fprintf(stderr, "device listener was not removed\n");
        return 1;
      }
    }
  }
  struct fake_device good = {0};
  spa_hook_list_init(&good.hooks);
  good.device.iface = SPA_INTERFACE_INIT(SPA_TYPE_INTERFACE_Device,
      SPA_VERSION_DEVICE, &methods, &good);
  struct pw_proxy *p = pw_core_export(core, SPA_TYPE_INTERFACE_Device,
      NULL, &good.device, 0);
  if (!p) {
    perror("valid device export");
    return 1;
  }
  struct spa_hook hook = {0};
  pw_proxy_add_listener(p, &hook, &proxy_events, &good);
  double deadline = now() + 2;
  while (!good.bound && now() < deadline)
    pw_loop_iterate(pw_main_loop_get_loop(loop), 50);
  if (!good.bound) {
    fprintf(stderr, "valid device did not become bound\n");
    return 1;
  }
  pw_proxy_destroy(p);
  if (!spa_list_is_empty(&good.hooks.list))
    return 1;
  pw_core_disconnect(core);
  pw_context_destroy(context);
  pw_main_loop_destroy(loop);
  pw_deinit();
  puts(fixed ? "PASS: six listener failures propagate errno and clean up; valid device binds"
             : "BASELINE REPRODUCED: six listener errors were ignored; valid device binds");
  return 0;
}
