# PipeWire / WirePlumber 设备导出失败根修材料

这里包含两个配套底层补丁和可以单独复现的回归测试。补丁基于 **PipeWire 1.6.9、WirePlumber 0.5.18**；需要迁移到更新分支时，先按当前源码复核。

PipeWire 的 client-device 导出忽略 SPA `add_listener` 的错误，返回一个永远无法完成绑定的 proxy。WirePlumber 又等待绑定完成，使设备激活及其异步 hook 无法结束。两个补丁分别传播 listener 错误，以及在导出返回 NULL 时结束激活。这是 Anland 音频故障涉及的通用失败路径；Anland 的 Qualcomm 控制设备过滤属于另外的集成修复。

## 内容

- `pipewire-listener-error.patch`：销毁失败的 proxy，保留 errno，返回 NULL。
- `wireplumber-device-export-error.patch`：保存导出错误，在解锁后终止激活。
- `tests/pipewire-export-error.c`：合成 SPA 设备，检查三种错误和两种 listener 建立状态，共六项失败，以及正常设备能否绑定。
- `tests/wp-spa-device-export-error.c`：不存在的 V4L2 路径，检查主 context 和 threaded client context 的错误回调，以及失败后的 core 请求仍能完成。
- `tests/common/`：从 WirePlumber 0.5.18 复制的三份小型 MIT 测试 fixture 头文件，保留上游版权声明。
- `run-regressions.py`：编译、启动独立测试服务、运行对照、保存日志、清理临时文件。
- `logs/pre-install/`：2026 年 10 月 13 日 **安装底层补丁前的隔离测试**及报告；文件时间使用 Asia/Shanghai，见 `manifest.json`。它们不代表安装后的实际桌面播放结果。
- `results/portable-run/`：新版可移植运行器的隔离重跑结果。

这里没有二进制、完整上游源码或 Git commit。

## 构建与运行

需要 Linux、Python 3、C 编译器、pkg-config，以及 PipeWire、SPA、GLib/GIO、WirePlumber 0.5 开发文件。还需要一个同版本 PipeWire daemon 可执行文件，用于私有测试服务。

分别在对应上游源码树应用补丁，然后按项目构建说明编译。WirePlumber 可只构建库和 C 测试，不需要替换系统 daemon。将修补后的模块目录、WirePlumber 库目录传给运行器：

```sh
python3 run-regressions.py \
  --patched-module-dir /path/to/pipewire/build/src/modules:/usr/lib/pipewire-0.3 \
  --patched-wp-lib-dir /path/to/wireplumber/build/lib/wp
```

示例中的发行版模块目录要按自己的系统调整，可用 `pkg-config --variable=moduledir libpipewire-0.3` 查询。SPA 目录默认由 pkg-config 查找，也可以通过 `--spa-plugin-dir` 指定。需要使用新构建的 PipeWire 动态库或 daemon 时，分别加 `--pipewire-lib-dir`、`--pipewire-executable`。

如果没有安装 WirePlumber 开发头文件，可以提供源码树与生成头文件所在的构建树：

```sh
python3 run-regressions.py \
  --patched-module-dir /path/to/pipewire/build/src/modules:/usr/lib/pipewire-0.3 \
  --patched-wp-lib-dir /path/to/wireplumber/build/lib/wp \
  --wp-source /path/to/wireplumber \
  --wp-build /path/to/wireplumber/build
```

运行器自动在 `/tmp/af-*` 的短路径内编译并运行。可以用 `--temp-parent` 选择另一个短临时目录；过长路径会被拒绝，防止 V4L2 插件内部的路径长度和 Unix socket 限制影响测试。材料包本身可以位于较深的目录。

测试使用独立配置和私有 PipeWire runtime，WP 测试启动自己的唯一 socket。只对一个不存在的临时文件调用 V4L2 设备接口，合成设备测试完全不使用硬件；不启动硬件监视器，不枚举摄像头，不连接正在运行的桌面音频服务。服务和库路径只通过测试子进程环境指定。测试结束后临时目录、私有服务与编译产物会被清理；日志保留在 `results/portable-run/`，或 `--output-dir` 指定的目录。

## 原版与修补版对照

同时提供未修补的目录，可以复现完整失败矩阵：

```sh
python3 run-regressions.py \
  --original-module-dir /path/to/original/pipewire/modules \
  --original-wp-lib-dir /path/to/original/wireplumber/lib \
  --patched-module-dir /path/to/patched/pipewire/modules:/usr/lib/pipewire-0.3 \
  --patched-wp-lib-dir /path/to/patched/wireplumber/lib
```

原版目录必须确实保存未修补的文件；安装修补包后，系统 `/usr/lib` 可能已经是修补版，应使用保留的原版构建或解包目录。

| PipeWire | WirePlumber | 预期结果 |
| --- | --- | --- |
| 原版 | 原版 | 没有激活回调，八秒 watchdog 触发 |
| 原版 | 修补版 | 同样没有激活回调 |
| 修补版 | 原版 | NULL proxy 断言，GLib 测试框架将 critical 作为失败 |
| 修补版 | 修补版 | 两种 context 均及时返回错误，后续 core 请求完成 |

原版 PipeWire 合成设备测试的“BASELINE REPRODUCED”表示成功复现旧缺陷。运行器会检查这些预期失败是否吻合，不会把任意失败当作复现成功。最终退出码 0 表示所有选择的组均符合预期，具体内容见 `report.json`。

## 已获得的结果

安装前对照证明两个修补都需要：旧版本组合未收到回调，单修 PipeWire 触发 WirePlumber NULL proxy 断言，成对修补使主 context 和 threaded client context 分别于 0.470 ms、0.299 ms 返回正确错误，随后 core 同步完成。PipeWire 的六项合成错误均传播正确 errno 并清理 listener；正常合成设备仍能绑定。

WirePlumber 的 `core`、`events`、`object-manager`、`proxy`、`transition`、`client-context` 六个相关上游测试套件通过。这里的隔离测试检查错误传播、清理和激活完成；真实 Android 音频播放结果由主交付报告单独记录。

## 分别提交给上游

PipeWire 补丁应提交到 [PipeWire 上游](https://gitlab.freedesktop.org/pipewire/pipewire)，WirePlumber 补丁应提交到 [WirePlumber 上游](https://gitlab.freedesktop.org/pipewire/wireplumber)。GitHub 仓库主要是镜像。建议分别说明各自的问题与修补结果，并互相引用两个 MR；将回归源码移入各项目现有测试框架，由维护者评审。Anland PR 可引用这些底层修复及其隔离证据。

WirePlumber 0.5.18 的 [AGENTS.md](https://github.com/PipeWire/wireplumber/blob/0.5.18/AGENTS.md)要求在 AI 协助的提交末尾添加 `Assisted-by` trailer，格式包含工具名称和**真实、完整的会话模型 ID**。提交时从实际会话确认并填写；本材料不猜测模型 ID，也不生成 commit。该文件明确禁止为 AI 添加 `Co-Authored-By`，并要求人类提交者自行承担 DCO 等责任；这里不生成或代填 `Signed-off-by`。
