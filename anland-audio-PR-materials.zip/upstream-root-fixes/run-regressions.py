#!/usr/bin/env python3
"""Compile and run isolated PipeWire/WirePlumber export regressions."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
import time
from zoneinfo import ZoneInfo

BUNDLE = Path(__file__).resolve().parent


def pkg_flags(*packages):
    return shlex.split(subprocess.check_output(
        ["pkg-config", "--cflags", "--libs", *packages], text=True))


def pkg_variable(package, variable):
    return subprocess.check_output(
        ["pkg-config", f"--variable={variable}", package], text=True).strip()


def run_record(name, command, env, output, expected, timeout=20):
    started = time.monotonic()
    try:
        process = subprocess.run(command, env=env, capture_output=True,
            text=True, timeout=timeout, cwd=env["PIPEWIRE_RUNTIME_DIR"])
        code, stdout, stderr = process.returncode, process.stdout, process.stderr
    except subprocess.TimeoutExpired as error:
        code = 124
        stdout = error.stdout or ""
        stderr = error.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
        stderr += "\nRunner timeout.\n"
    combined = stdout + stderr
    if expected == "fixed":
        matched = code == 0
    elif expected == "ignored-listener":
        matched = code == 0 and "BASELINE REPRODUCED" in stdout
    elif expected == "wp-null-proxy":
        matched = code != 0 and "wp_proxy_set_pw_proxy" in combined and "assertion" in combined
    else:
        matched = code != 0 and "test timed out" in combined
    (output / f"{name}.log").write_text(combined)
    record = {"name": name, "command": command, "expected": expected,
        "exit_code": code, "expectation_matched": matched,
        "elapsed_seconds": round(time.monotonic() - started, 4),
        "stdout": stdout, "stderr": stderr}
    print(f"{'PASS' if matched else 'FAIL'} {name} (exit {code})", flush=True)
    return record


def write_config(config):
    spa = """context.spa-libs = {
  support.* = support/libspa-support
  api.v4l2.* = v4l2/libspa-v4l2
  audio.convert.* = audioconvert/libspa-audioconvert
}
"""
    client = spa + """context.modules = [
  { name = libpipewire-module-protocol-native }
  { name = libpipewire-module-client-node }
  { name = libpipewire-module-client-device }
  { name = libpipewire-module-spa-node-factory }
  { name = libpipewire-module-adapter }
  { name = libpipewire-module-metadata }
]
"""
    server = """context.properties = {
  core.daemon = true
  core.name = pw-rootfix
}
""" + client.replace("context.modules = [",
        "context.modules = [\n  { name = libpipewire-module-access }", 1)
    (config / "client.conf").write_text(client)
    (config / "pipewire.conf").write_text(server)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--patched-module-dir", required=True,
        help="Colon separated PipeWire module search path; patched directory first")
    parser.add_argument("--patched-wp-lib-dir", required=True,
        help="Directory containing the patched libwireplumber-0.5.so")
    parser.add_argument("--original-module-dir",
        help="Optional original PipeWire module path, for before/after comparisons")
    parser.add_argument("--original-wp-lib-dir",
        help="Optional original WirePlumber library directory, for the full matrix")
    parser.add_argument("--pipewire-lib-dir",
        help="Optional directory containing libpipewire-0.3.so for all subprocesses")
    parser.add_argument("--spa-plugin-dir",
        help="SPA plugin directory; defaults to pkg-config libspa-0.2 plugindir")
    parser.add_argument("--pipewire-executable", default=shutil.which("pipewire"),
        help="PipeWire daemon executable used only for a private test server")
    parser.add_argument("--wp-source", type=Path,
        help="Optional WirePlumber source tree, to compile with source headers")
    parser.add_argument("--wp-build", type=Path,
        help="Matching build tree containing generated lib/wp headers")
    parser.add_argument("--cc", default="cc")
    parser.add_argument("--temp-parent", default="/tmp",
        help="Short temporary parent directory; the default avoids socket/path limits")
    parser.add_argument("--output-dir", type=Path, default=BUNDLE / "results" / "portable-run")
    args = parser.parse_args()
    if args.wp_source and not args.wp_build:
        parser.error("--wp-source needs --wp-build for generated headers")
    if not args.pipewire_executable:
        parser.error("A PipeWire daemon executable is required")
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    records = []
    with tempfile.TemporaryDirectory(prefix="af-", dir=args.temp_parent) as directory:
        temp = Path(directory).resolve()
        runtime, config = temp / "r", temp / "c"
        runtime.mkdir(mode=0o700)
        config.mkdir()
        missing = temp / "absent"
        if len(str(missing)) >= 64 or len(str(runtime)) >= 60:
            parser.error("Temporary path is too long; use --temp-parent /tmp or another short directory")
        assert not missing.exists()
        write_config(config)
        env = os.environ.copy()
        for key in ("PIPEWIRE_REMOTE", "PIPEWIRE_CONFIG_PREFIX"):
            env.pop(key, None)
        env.update({"XDG_RUNTIME_DIR": str(runtime),
            "PIPEWIRE_RUNTIME_DIR": str(runtime),
            "PIPEWIRE_CONFIG_DIR": str(config),
            "XDG_CONFIG_HOME": str(temp / "xdg-config"),
            "XDG_STATE_HOME": str(temp / "xdg-state"),
            "WIREPLUMBER_CONFIG_DIR": str(config),
            "WIREPLUMBER_DATA_DIR": str(temp / "empty-data"),
            "ANLAND_TEST_MISSING_V4L2_PATH": str(missing),
            "SPA_PLUGIN_DIR": args.spa_plugin_dir or pkg_variable("libspa-0.2", "plugindir"),
            "WIREPLUMBER_DEBUG": "2"})

        def variant_env(module_path, wp_library=None):
            current = env.copy()
            current["PIPEWIRE_MODULE_DIR"] = module_path
            libraries = [path for path in (wp_library, args.pipewire_lib_dir) if path]
            if libraries:
                current["LD_LIBRARY_PATH"] = ":".join(libraries)
            else:
                current.pop("LD_LIBRARY_PATH", None)
            return current

        pw_binary, wp_binary = temp / "pw-test", temp / "wp-test"
        pw_flags = pkg_flags("libpipewire-0.3")
        if args.wp_source:
            wp_flags = pkg_flags("glib-2.0", "gio-2.0", "libpipewire-0.3")
            wp_flags += ["-I" + str(args.wp_source.resolve() / "lib"),
                "-I" + str(args.wp_build.resolve() / "lib"),
                "-I" + str(args.wp_build.resolve() / "lib/wp"), "-lwireplumber-0.5"]
        else:
            wp_flags = pkg_flags("wireplumber-0.5", "libpipewire-0.3")
        compile_commands = [
            [args.cc, "-Wall", "-Wextra", "-Wno-unused-parameter",
                str(BUNDLE / "tests/pipewire-export-error.c"), "-o", str(pw_binary)] + pw_flags,
            [args.cc, "-Wall", "-Wextra", "-Wno-unused-parameter",
                str(BUNDLE / "tests/wp-spa-device-export-error.c"), "-o", str(wp_binary),
                "-L" + args.patched_wp_lib_dir] + wp_flags,
        ]
        compile_log = []
        for command in compile_commands:
            completed = subprocess.run(command, capture_output=True, text=True)
            compile_log.append("COMMAND: " + shlex.join(command) + "\n" + completed.stdout + completed.stderr)
            if completed.returncode:
                (output / "compile.log").write_text("\n".join(compile_log))
                raise SystemExit("Compilation failed; see compile.log")
        (output / "compile.log").write_text("\n".join(compile_log))

        pw_variants = [("patched", args.patched_module_dir, "fixed")]
        if args.original_module_dir:
            pw_variants.insert(0, ("original", args.original_module_dir, "ignored-listener"))
        for label, modules, expected in pw_variants:
            current = variant_env(modules)
            server_log = output / f"pipewire-{label}-server.log"
            with server_log.open("w") as log:
                server = subprocess.Popen([args.pipewire_executable, "-c", "pipewire.conf"],
                    env=current, stdout=log, stderr=subprocess.STDOUT, cwd=temp)
                try:
                    deadline = time.monotonic() + 5
                    while not (runtime / "pw-rootfix").exists():
                        if server.poll() is not None or time.monotonic() > deadline:
                            raise RuntimeError(f"Private server did not start; see {server_log}")
                        time.sleep(0.02)
                    current["PIPEWIRE_REMOTE"] = "pw-rootfix"
                    records.append(run_record(f"pipewire-{label}",
                        [str(pw_binary), "fixed" if label == "patched" else "baseline"],
                        current, output, expected))
                finally:
                    server.terminate()
                    try:
                        server.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait()

        matrix = [("wp-patched-pair", args.patched_module_dir,
            args.patched_wp_lib_dir, "fixed")]
        if args.original_module_dir:
            matrix.insert(0, ("wp-patched-wp-original-pw", args.original_module_dir,
                args.patched_wp_lib_dir, "wp-stalled"))
        if args.original_wp_lib_dir:
            matrix.insert(0, ("wp-original-wp-patched-pw", args.patched_module_dir,
                args.original_wp_lib_dir, "wp-null-proxy"))
            if args.original_module_dir:
                matrix.insert(0, ("wp-original-pair", args.original_module_dir,
                    args.original_wp_lib_dir, "wp-stalled"))
        for name, modules, library, expected in matrix:
            records.append(run_record(name, [str(wp_binary)],
                variant_env(modules, library), output, expected))

    report = {"completed_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "phase": "portable isolated regression; not a live desktop audio test",
        "temporary_files_removed": True, "results": records,
        "all_expectations_matched": all(record["expectation_matched"] for record in records)}
    (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"Report: {output / 'report.json'}")
    return 0 if report["all_expectations_matched"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
